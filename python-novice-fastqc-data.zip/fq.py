#!/usr/bin/eny python
import os
import sys

class FQRead(object):
    def __init__(self, *args):
        self.id_ = args[0].strip()
        self.seq = args[1].strip()
        self.qual = args[3].strip()
    def __getitem__(self, key):
        if key == 0:
            return self.id_
        elif key == 1:
            return self.seq
        elif key == 2:
            return '+'
        elif key == 3:
            return self.qual
    def __str__(self):
        return '%s\n%s\n+\n%s\n' % (self.id_, self.seq, self.qual)
    def __repr__(self):
        return str(self)

class FQReads(object):
    def __init__(self, *args):
        self.reads = []
        if args:
            assert os.path.exists(args[0])
            #self.reads = list(read_fq(args[0]))
            with open(args[0]) as fi:
                for id_ in fi:
                    try:
                        # read_data = id_,fi.next(), fi.next(), fi.next()
                        read_data = id_, next(fi), next(fi), next(fi)
                    except:
                        break
                    self.reads.append(FQRead(*read_data))
                    # print(self.reads)

    def append(self, read):
        self.reads.append(read)
    def __delitem__(self, key):
        del self.reads[key]
    def __getitem__(self, key):
        return self.reads[key]
    def ___setitem__(self, key, value):
        self.reads[key] = value
    def __len__(self):
        return len(self.reads)
    def __str__(self):
        string = '[\n'
        for read in self.reads[:2]:
            string += '    ' + str(read).strip().replace('\n', '\n    ') + ',\n\n'
        if len(self.reads) > 2:
            string += '    ...\n\n'
            for read in self.reads[-2:]:
                string += '    ' + str(read).strip().replace('\n', '\n    ') + ',\n\n'
        string = string.strip(',\n\n') + '\n]'
        return string
    def __repr(self):
        return str(self)

def read_fq_pretty(fn):
    fqr = FQReads(fn)
    # sys.stdout.write(str(fqr) + '\n')
    return fqr
#def read_fq_quick(fn):
#    return

def read_fq(fn):
    with open(fn) as fi:
        for id_ in fi:
            try:
                seq, sep, qual = next(fi), next(fi), next(fi)
            except:
                break
            yield (id_.strip(), seq.strip(), sep.strip(), qual.strip())

def get_qualplot(qual):
    return list(map(lambda x:x+1, range(len(qual)))), list(map(lambda x:ord(x)-33, qual))

def get_baseplot(seqs):
    base_composition = [[0,0,0,0,0] for base in seqs[0][1]]
    d = {'A': 0, 'C': 1, 'G': 2, 'T': 3}
    for read in seqs:
        seq = read[1]
        for i, base in enumerate(seq):
            base_composition[i][d.get(base, 4)] += 1
    y = []
    for base in 'ACGTN':
        y.append([])
    for i, base in enumerate('ACGTN'):
        for j, pos in enumerate(base_composition):
            y[i].append(pos[i] / float(len(seqs)))
    return range(len(seq)), y


def fq2list(fn):
    return list(read_fq(fn))

def main():
    pass

if __name__ == '__main__': main()
